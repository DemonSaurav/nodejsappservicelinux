# Sample Node.js Websocket based CHAT application

 - You can deploy this web application as-is to Azure App Service on Linux.

